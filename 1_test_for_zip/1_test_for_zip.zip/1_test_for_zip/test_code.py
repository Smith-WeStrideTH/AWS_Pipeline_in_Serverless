import json
  
def lambda_handler(event, context):
    print("Welcome to Lambda!!")


